const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, '..', 'data', 'db.json');
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

function readDB() {
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ products: [], orders: [], nextOrderId: 1001 }, null, 2));
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function writeDB(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
function safeProduct(p) { return { id: Number(p.id), name: String(p.name || '').trim(), category: String(p.category || 'Other'), price: Number(p.price), unit: String(p.unit || 'item'), stock: Number(p.stock), rating: Number(p.rating || 4.5), badge: String(p.badge || 'Fresh pick'), emoji: String(p.emoji || '🛒'), image: String(p.image || ''), description: String(p.description || '') }; }
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'GroceryEase API' }));
app.get('/api/products', (req, res) => {
  let products = readDB().products;
  if (req.query.category && req.query.category !== 'All') products = products.filter(p => p.category === req.query.category);
  if (req.query.q) { const q = String(req.query.q).toLowerCase(); products = products.filter(p => `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q)); }
  res.json(products);
});
app.post('/api/products', (req, res) => {
  const p = safeProduct(req.body);
  if (!p.name || !Number.isFinite(p.price) || p.price < 0 || !Number.isFinite(p.stock) || p.stock < 0) return res.status(400).json({ error: 'Enter a name, a valid price, and a valid stock quantity.' });
  const db = readDB(); p.id = Math.max(0, ...db.products.map(x => Number(x.id))) + 1; db.products.unshift(p); writeDB(db); res.status(201).json(p);
});
app.put('/api/products/:id', (req, res) => {
  const db = readDB(); const index = db.products.findIndex(p => p.id === Number(req.params.id));
  if (index < 0) return res.status(404).json({ error: 'Product not found.' });
  const p = safeProduct({ ...db.products[index], ...req.body, id: Number(req.params.id) });
  if (!p.name || !Number.isFinite(p.price) || p.price < 0 || !Number.isFinite(p.stock) || p.stock < 0) return res.status(400).json({ error: 'Invalid product fields.' });
  db.products[index] = p; writeDB(db); res.json(p);
});
app.delete('/api/products/:id', (req, res) => { const db = readDB(); const before = db.products.length; db.products = db.products.filter(p => p.id !== Number(req.params.id)); if (db.products.length === before) return res.status(404).json({ error: 'Product not found.' }); writeDB(db); res.json({ ok: true }); });
app.get('/api/orders', (_req, res) => res.json(readDB().orders.slice().reverse()));
app.post('/api/orders', (req, res) => {
  const { customer, phone, address, items, paymentMethod } = req.body || {};
  if (!customer || !phone || !address || !Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Please complete delivery details and add items to your cart.' });
  const db = readDB(); const normalized = [];
  for (const item of items) {
    const product = db.products.find(p => p.id === Number(item.id)); const qty = Math.floor(Number(item.qty));
    if (!product || !Number.isFinite(qty) || qty < 1) return res.status(400).json({ error: 'One or more cart items are invalid.' });
    if (product.stock < qty) return res.status(409).json({ error: `${product.name} does not have enough stock.` });
    normalized.push({ id: product.id, name: product.name, price: product.price, qty, emoji: product.emoji });
  }
  normalized.forEach(item => { const p = db.products.find(x => x.id === item.id); p.stock -= item.qty; });
  const subtotal = normalized.reduce((sum, item) => sum + item.price * item.qty, 0); const delivery = subtotal >= 499 ? 0 : 30;
  const order = { id: db.nextOrderId++, code: `GE${Date.now().toString().slice(-6)}`, customer: String(customer).trim(), phone: String(phone).trim(), address: String(address).trim(), items: normalized, subtotal, delivery, total: subtotal + delivery, paymentMethod: String(paymentMethod || 'Cash on delivery'), status: 'Confirmed', createdAt: new Date().toISOString() };
  db.orders.push(order); writeDB(db); res.status(201).json(order);
});
app.patch('/api/orders/:id/status', (req, res) => {
  const allowed = ['Confirmed', 'Preparing', 'Out for delivery', 'Delivered', 'Cancelled'];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: 'Invalid order status.' });
  const db = readDB(); const order = db.orders.find(o => o.id === Number(req.params.id)); if (!order) return res.status(404).json({ error: 'Order not found.' }); order.status = req.body.status; writeDB(db); res.json(order);
});
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.listen(PORT, () => console.log(`GroceryEase is running at http://localhost:${PORT}`));
